function PhonePicker({index, change, onEmoji, onSticker, disabled}) {
  const h = je.createElement;
  const names = ["喝杯茶", "打个盹", "加油呀", "去打球", "嗨", "太棒了"];
  const stickers = index === _L.length;
  return h("section", {className:"phone-picker", "aria-label":"选择表情"},
    h("div", {className:"emoji-categories"},
      [..._L.map(category=>category[0]),"荔枝贴纸"].map((name,i)=>
        h("button",{type:"button",key:name,"aria-pressed":i===index,onClick:()=>change(i)},name))),
    h("div",{className:"emoji-grid"+(stickers?" stickers":""),key:index},stickers
      ? names.map((name,i)=>h("button",{type:"button",key:name,disabled,"aria-label":name,onClick:()=>onSticker(i)},
          h("img",{src:"/mobile/sticker-"+i+".jpg",alt:name})))
      : _L[index][1].split(" ").map((emoji,i)=>h("button",{key:i,type:"button",onClick:()=>onEmoji(emoji)},emoji))));
}
