// Integrated into the existing React bundle alongside the mobile page.
async function circleRequest(query = "", payload, signal) {
  const options = {cache:"no-store", signal: signal || AbortSignal.timeout(15000)};
  if (payload) Object.assign(options, {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)
  });
  const response = await fetch("/api/phone/circles" + query, options);
  if (response.status === 401) throw Error("请重新登录便签");
  if (!response.ok) {
    const detail = await response.json().catch(() => ({}));
    throw Error(detail.error || "暂时没有连上，请重试");
  }
  return response.json();
}

function CircleCaption({circle, onCommit, onCancelNew, onRemove, unread=0}) {
  const h = Ee.createElement;
  const [draft,setDraft] = Ee.useState(circle.isNew ? {...circle} : null);
  const [error,setError] = Ee.useState("");
  const [busy,setBusy] = Ee.useState(false);
  const pending = Ee.useRef(false);
  function edit() {setError("");setDraft({...circle});}
  function cancel() {
    if (pending.current) return;
    setError("");setDraft(null);
    if (circle.isNew) onCancelNew();
  }
  async function write(remove=false) {
    if (pending.current || !draft) return;
    if (remove && !window.confirm("删除「"+circle.name+"」？")) return;
    const name=draft.name.trim(), subtitle=draft.subtitle.trim();
    if (!remove && !name) return;
    if (!remove && !circle.isNew && name===circle.name && subtitle===circle.subtitle) {cancel();return;}
    pending.current=true;setBusy(true);setError("");
    try {
      const action=remove?"delete":circle.isNew?"create":"update";
      await circleRequest("",{action,id:circle.id,name,subtitle,revision:draft.revision});
      if(remove) onRemove(circle.id);
      else onCommit({id:circle.id,name,subtitle,revision:(draft.revision||0)+1});
      setDraft(null);
    } catch(e){setError(e.message);}
    finally{pending.current=false;setBusy(false);}
  }
  function line(field,label,limit) {
    const title=field==="name", style=title?"circle-name-line":"circle-sub-line";
    if(draft) return h("input",{className:style,"aria-label":label,placeholder:label,
      maxLength:limit,value:draft[field],required:title,autoFocus:title,disabled:busy,
      onChange:event=>setDraft({...draft,[field]:event.target.value})});
    return h(title?"strong":"span",{className:style},circle[field]);
  }
  const lines=[line("name","圈名",30),line("subtitle","小标签",60)];
  return draft ? h("form",{className:"circle-lines",onSubmit:e=>{e.preventDefault();write();},
    onKeyDown:e=>{if(e.key==="Escape")cancel();}},...lines,
    h("div",{className:"inline-actions"},
      h("button",{disabled:busy||!draft.name.trim(),type:"submit"},"保存"),
      h("button",{disabled:busy,type:"button",onClick:cancel},"取消"),
      !circle.isNew&&h("button",{disabled:busy,type:"button",onClick:()=>write(true)},"删除")),
    error&&h("small",{role:"alert"},error)) :
    h("div",{className:"circle-lines circle-readonly"},
      h("div",{className:"circle-text"},...lines,unread>0&&h("small",null,unread+" 条未读")),
      h("button",{type:"button",className:"circle-edit-action","aria-label":"编辑"+circle.name,onClick:edit},"编辑"));
}

function CircleList({open,unread}) {
  const h=Ee.createElement;
  const [circles,setCircles]=Ee.useState(null),[creating,setCreating]=Ee.useState(null),[error,setError]=Ee.useState("");
  const seq=Ee.useRef(0);
  async function refresh(){
    const current=++seq.current;
    try{const data=await circleRequest();if(current===seq.current){setCircles(data.circles);setError("");}}
    catch(e){if(current===seq.current)setError(e.message);}
  }
  Ee.useEffect(()=>{refresh();const timer=setInterval(()=>{if(!document.hidden)refresh();},15000);
    return ()=>{seq.current++;clearInterval(timer);};},[]);
  const entries=creating?[creating,...(circles||[])]:circles||[];
  function commit(next){
    seq.current++;
    setCreating(null);
    setCircles(items=>items?.some(x=>x.id===next.id)?items.map(x=>x.id===next.id?next:x):[...(items||[]),next]);
    refresh();
  }
  function remove(id){seq.current++;setCircles(items=>(items||[]).filter(x=>x.id!==id));}
  return h("section",{className:"circle-list"},
    h("div",{className:"circle-tools"},h("h2",null,"我的圈子"),
      h("button",{type:"button",disabled:!!creating,onClick:()=>setCreating({id:crypto.randomUUID(),name:"",subtitle:"",isNew:true})},"＋ 新建圈子")),
    error&&h("p",{role:"alert"},error," ",h("button",{type:"button",onClick:refresh},"重试")),
    !circles&&!error&&!creating&&h("p",null,"正在读取圈子…"),
    circles&&!entries.length&&h("p",null,"还没有圈子，可以创建第一个。"),
    entries.map(circle=>h("article",{key:circle.id,className:"circle-entry"},
      circle.isNew?h("img",{className:"circle-banner",src:"/mobile/break-room.webp",alt:""}):
        h("button",{type:"button",className:"circle-picture","aria-label":"进入"+circle.name,onClick:()=>open(circle)},
          h("img",{className:"circle-banner",src:"/mobile/break-room.webp",alt:""})),
      h("div",{className:"circle-caption-row"},
        h(CircleCaption,{circle,onCommit:commit,onRemove:remove,onCancelNew:()=>setCreating(null),unread:circle.id==="main"?unread:0}),
        !circle.isNew&&h("button",{type:"button",className:"circle-enter","aria-label":"进入"+circle.name,onClick:()=>open(circle)},h(Ta,{name:"next",size:20}))))));
}

function CircleRoom({circle, chat, avatar, back}) {
  const h=Ee.createElement;
  const [notes,setNotes]=Ee.useState([]);
  const [text,setText]=Ee.useState("");
  const [picture,setPicture]=Ee.useState("");
  const [reply,setReply]=Ee.useState("");
  const [error,setError]=Ee.useState("");
  const [busy,setBusy]=Ee.useState(false);
  const sending=Ee.useRef(false);
  const requestId=Ee.useRef(null);
  const generation=Ee.useRef(0);
  const query="?room="+encodeURIComponent(circle.id);
  async function load() {
    const ticket=++generation.current;
    try {
      const data=await circleRequest(query);
      if(ticket===generation.current) {setNotes(data.notes);setError("");}
    } catch(e) {if(ticket===generation.current) setError(e.message);}
  }
  Ee.useEffect(()=>{
    load();
    const timer=setInterval(()=>{if(!document.hidden)load();},5000);
    return ()=>{clearInterval(timer);generation.current++;};
  },[circle.id]);
  async function post(payload) {
    if (sending.current) return;
    sending.current=true;setBusy(true);setError("");
    try {
      await circleRequest(query,payload);
      if(payload.action==="send"){setText("");setPicture("");setReply("");requestId.current=null;}
      await load();
    } catch(e){setError(e.message);}
    finally {sending.current=false;setBusy(false);}
  }
  function change(setter,value) {requestId.current=null;setter(value);}
  return h(so,{...chat,hideDaily:true,invite:null,avatarUrl:avatar,back,notes,busy,text,picture,
    composeIcons:{photo:h(Vn,{size:22}),emoji:h(Ol,{size:21}),send:h(Xn,{size:19})},
    onText:value=>change(setText,value),onPicture:value=>change(setPicture,value),replyTo:reply,
    onReply:value=>change(setReply,value),onMention:()=>{},error,
    imageUrl:id=>"/api/phone/circles"+query+"&image="+encodeURIComponent(id),
    onSend:()=>{requestId.current ||= crypto.randomUUID();
      post({action:"send",clientId:requestId.current,body:text.trim(),picture,replyTo:reply});},
    onRecall:id=>post({action:"recall",id})});
}
