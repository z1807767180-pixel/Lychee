// Integrated into the existing React bundle alongside the mobile page.
async function circleRequest(query = "", payload, signal) {
  const options = {cache:"no-store", signal: signal || AbortSignal.timeout(15000)};
  if (payload) Object.assign(options, {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)
  });
  const response = await fetch("/api/phone/circles" + query, options);
  if (response.status === 401) throw Error("请重新登录便签");
  if (!response.ok) {
    const detail = await response.json().catch(() => ({}));
    throw Error(detail.error || "暂时没有连上，请重试");
  }
  return response.json();
}

function CircleList({open, unread}) {
  const h = Ee.createElement;
  const [circles, setCircles] = Ee.useState(null);
  const [draft, setDraft] = Ee.useState(null);
  const [error, setError] = Ee.useState("");
  const [busy, setBusy] = Ee.useState(false);
  const revision = Ee.useRef(0);
  const saving = Ee.useRef(false);
  async function refresh() {
    const ticket = ++revision.current;
    try {
      const data = await circleRequest();
      if (revision.current === ticket) {setCircles(data.circles); setError("");}
    } catch (e) { if (revision.current === ticket) setError(e.message); }
  }
  Ee.useEffect(() => {
    refresh();
    const timer = setInterval(() => { if (!document.hidden) refresh(); },15000);
    return () => { revision.current++; clearInterval(timer); };
  },[]);
  async function submit(action) {
    if (saving.current) return;
    saving.current = true; setBusy(true); setError("");
    try {
      await circleRequest("", {action, id:draft.id, name:draft.name.trim(),
        subtitle:draft.subtitle.trim(), revision:draft.revision});
      setDraft(null);
      await refresh();
    } catch (e) { setError(e.message); } finally {saving.current=false;setBusy(false);}
  }
  function field(label, key, limit) {
    return h("label",null,label,h("input",{value:draft[key],maxLength:limit,required:key==="name",
      disabled:busy,onChange:e=>setDraft({...draft,[key]:e.target.value})}));
  }
  return h("section",{className:"circle-list"},
    h("div",{className:"circle-tools"},h("h2",null,"我的圈子"),
      h("button",{type:"button",disabled:busy,onClick:()=>setDraft({id:crypto.randomUUID(),name:"",subtitle:"",isNew:true})},"＋ 新建圈子")),
    error && h("p",{role:"alert"},error," ",h("button",{type:"button",onClick:refresh},"重试")),
    draft && h("form",{className:"cardform circle-form",onSubmit:e=>{e.preventDefault();if(draft.name.trim())submit(draft.isNew?"create":"update");}},
      field("圈子名称","name",30),field("小标签","subtitle",60),
      h("div",{className:"circle-tools"},h("button",{className:"solid",disabled:busy||!draft.name.trim()},"保存"),
        h("button",{type:"button",disabled:busy,onClick:()=>setDraft(null)},"取消"),
        !draft.isNew && h("button",{type:"button",disabled:busy,onClick:()=>{
          if (window.confirm("从小队的圈子列表删除「"+draft.name+"」？")) submit("delete");
        }},"删除圈子"))),
    circles === null && !error && h("p",null,"正在读取圈子…"),
    circles && circles.length===0 && !draft && h("p",null,"还没有圈子，可以创建第一个。"),
    circles && circles.map(circle=>h("article",{key:circle.id,className:"circle-entry"},
      h("button",{type:"button",className:"circle-cover",onClick:()=>open(circle)},
        h("img",{src:"/mobile/break-room.webp",alt:""}),
        h("span",{className:"circle-caption"},h("strong",null,circle.name),
          h(Ta,{name:"next",size:20}),h("small",null,circle.subtitle,
            circle.id==="main"&&unread>0?" · "+unread+" 条未读":""))),
      h("button",{type:"button",className:"circle-edit","aria-label":"编辑"+circle.name,
        onClick:()=>setDraft({...circle})},"编辑"))));
}

function CircleRoom({circle, chat, avatar, back}) {
  const h=Ee.createElement;
  const [notes,setNotes]=Ee.useState([]);
  const [text,setText]=Ee.useState("");
  const [picture,setPicture]=Ee.useState("");
  const [reply,setReply]=Ee.useState("");
  const [error,setError]=Ee.useState("");
  const [busy,setBusy]=Ee.useState(false);
  const sending=Ee.useRef(false);
  const requestId=Ee.useRef(null);
  const generation=Ee.useRef(0);
  const query="?room="+encodeURIComponent(circle.id);
  async function load() {
    const ticket=++generation.current;
    try {
      const data=await circleRequest(query);
      if(ticket===generation.current) {setNotes(data.notes);setError("");}
    } catch(e) {if(ticket===generation.current) setError(e.message);}
  }
  Ee.useEffect(()=>{
    load();
    const timer=setInterval(()=>{if(!document.hidden)load();},5000);
    return ()=>{clearInterval(timer);generation.current++;};
  },[circle.id]);
  async function post(payload) {
    if (sending.current) return;
    sending.current=true;setBusy(true);setError("");
    try {
      await circleRequest(query,payload);
      if(payload.action==="send"){setText("");setPicture("");setReply("");requestId.current=null;}
      await load();
    } catch(e){setError(e.message);}
    finally {sending.current=false;setBusy(false);}
  }
  function change(setter,value) {requestId.current=null;setter(value);}
  return h(so,{...chat,hideDaily:true,invite:null,avatarUrl:avatar,back,notes,busy,text,picture,
    composeIcons:{photo:h(Vn,{size:22}),emoji:h(Ol,{size:21}),send:h(Xn,{size:19})},
    onText:value=>change(setText,value),onPicture:value=>change(setPicture,value),replyTo:reply,
    onReply:value=>change(setReply,value),onMention:()=>{},error,
    imageUrl:id=>"/api/phone/circles"+query+"&image="+encodeURIComponent(id),
    onSend:()=>{requestId.current ||= crypto.randomUUID();
      post({action:"send",clientId:requestId.current,body:text.trim(),picture,replyTo:reply});},
    onRecall:id=>post({action:"recall",id})});
}
